# InvestaPlus

InvestaPlus — Demo DeFi platform (dark theme) for simulating 1% daily compound interest on TRX deposits.

Structure:
- frontend/ (Vite + React)
- backend/ (Node.js + Express + SQLite)
- docker-compose.yml
- deploy_instructions.md

IMPORTANT: Demo only. Do NOT use with real funds.
