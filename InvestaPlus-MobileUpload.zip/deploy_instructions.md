Deploy Frontend (Vercel):
1. Push frontend folder to GitHub and import to Vercel.
2. Build command: npm run build. Output dir: dist.

Deploy Backend (Railway/Render):
1. Push backend to GitHub.
2. Set env JWT_SECRET.
3. Optionally set DATABASE_URL for Postgres.

Use TronLink + Shasta testnet for TRON interactions.
