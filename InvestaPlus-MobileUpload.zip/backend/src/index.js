const express=require('express'), bodyParser=require('body-parser'), jwt=require('jsonwebtoken'), bcrypt=require('bcryptjs')
const DB=require('./db')
const app=express(); app.use(bodyParser.json())
const SECRET=process.env.JWT_SECRET||'investa_secret'
function authMiddleware(req,res,next){const auth=req.headers.authorization; if(!auth) return next(); const parts=auth.split(' '); if(parts.length!==2) return next(); try{req.user=jwt.verify(parts[1],SECRET)}catch(e){} next()}
app.use(authMiddleware)
app.post('/api/auth/register',(req,res)=>{const{email,password}=req.body; if(!email||!password) return res.status(400).json({message:'Missing'}); if(DB.getUserByEmail(email)) return res.status(400).json({message:'User exists'}); const hash=bcrypt.hashSync(password,10); const id=DB.createUser(email,hash); const token=jwt.sign({id,email},SECRET); res.json({token})})
app.post('/api/auth/login',(req,res)=>{const{email,password}=req.body; if(!email||!password) return res.status(400).json({message:'Missing'}); const user=DB.getUserByEmail(email); if(!user) return res.status(400).json({message:'No such user'}); if(!bcrypt.compareSync(password,user.password)) return res.status(400).json({message:'Wrong password'}); const token=jwt.sign({id:user.id,email:user.email},SECRET); res.json({token})})
app.get('/api/balance',(req,res)=>{ if(!req.user) return res.json(DB.getDemo()); res.json(DB.getBalance(req.user.id)) })
app.post('/api/deposit',(req,res)=>{ const amt=Number(req.body.amount); if(!req.user) return res.json(DB.demoDeposit(amt)); if(!amt||amt<=0) return res.status(400).json({message:'Invalid'}); res.json(DB.deposit(req.user.id,amt))})
app.post('/api/withdraw',(req,res)=>{ const amt=Number(req.body.amount); if(!req.user) return res.json(DB.demoWithdraw(amt)); if(!amt||amt<=0) return res.status(400).json({message:'Invalid'}); res.json(DB.withdraw(req.user.id,amt))})
app.post('/api/accrue',(req,res)=>{ res.json(DB.accrueAll()) })
const PORT=process.env.PORT||4000; app.listen(PORT,()=>console.log('Server listening on',PORT))
