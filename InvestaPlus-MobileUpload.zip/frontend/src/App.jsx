import React,{useState} from 'react'
import { translations } from './translations'
import Header from './components/Header'
import Login from './components/Login'
import Register from './components/Register'
import Dashboard from './components/Dashboard'
const STORAGE_LANG='investa_lang', STORAGE_TOKEN='investa_token'
export default function App(){
  const [lang,setLang]=useState(localStorage.getItem(STORAGE_LANG)||'bg')
  const [page,setPage]=useState('home')
  const [token,setToken]=useState(localStorage.getItem(STORAGE_TOKEN)||null)
  function t(k){return translations[lang][k]||k}
  function handleLoginDone(jwt){setToken(jwt);localStorage.setItem(STORAGE_TOKEN,jwt);setPage('dashboard')}
  function handleLogout(){setToken(null);localStorage.removeItem(STORAGE_TOKEN);setPage('home')}
  return (<div className='app'><div className='card'><Header t={t} lang={lang} setLang={setLang} onNavigate={(p)=>setPage(p)} isLoggedIn={!!token} onLogout={handleLogout} />
    <div style={{marginTop:12}}>
      <h2>{t('subtitle')}</h2>
      {page==='home'&&(<div style={{marginTop:12}}><p className='small'>Demo platform — използвайте тестова мрежа.</p><div style={{marginTop:12,display:'flex',gap:8}}><button className='btn' onClick={()=>setPage('login')}>{t('login')} / {t('register')}</button><button className='btn' onClick={()=>setPage('dashboard')}>Open demo (no auth)</button></div></div>)}
      {page==='login'&&<Login t={t} onDone={handleLoginDone} onSwitch={()=>setPage('register')} />}
      {page==='register'&&<Register t={t} onDone={handleLoginDone} onSwitch={()=>setPage('login')} />}
      {page==='dashboard'&&<Dashboard t={t} token={token} />}
    </div></div></div>)
}
