const express = require('express')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
const fs = require('fs')
const path = require('path')

const DB = require('./db')

const app = express()
app.use(bodyParser.json())

const SECRET = process.env.JWT_SECRET || 'investa_secret'

function authMiddleware(req,res,next){
  const auth = req.headers.authorization
  if(!auth) return next()
  const parts = auth.split(' ')
  if(parts.length!==2) return next()
  const token = parts[1]
  try{
    const data = jwt.verify(token, SECRET)
    req.user = data
  }catch(e){}
  next()
}
app.use(authMiddleware)

// register
app.post('/api/auth/register', async (req,res)=>{
  const {email,password} = req.body
  if(!email || !password) return res.status(400).json({message:'Missing'})
  const existing = DB.getUserByEmail(email)
  if(existing) return res.status(400).json({message:'User exists'})
  const hash = bcrypt.hashSync(password,10)
  const userId = DB.createUser(email,hash)
  const token = jwt.sign({id:userId,email}, process.env.JWT_SECRET || 'investa_secret')
  return res.json({token})
})

// login
app.post('/api/auth/login', (req,res)=>{
  const {email,password} = req.body
  if(!email || !password) return res.status(400).json({message:'Missing'})
  const user = DB.getUserByEmail(email)
  if(!user) return res.status(400).json({message:'No such user'})
  const ok = bcrypt.compareSync(password, user.password)
  if(!ok) return res.status(400).json({message:'Wrong password'})
  const token = jwt.sign({id:user.id,email:user.email}, process.env.JWT_SECRET || 'investa_secret')
  res.json({token})
})

// get balance
app.get('/api/balance', (req,res)=>{
  if(!req.user) {
    // demo mode: load from file local demo store
    const demo = DB.getDemo()
    return res.json(demo)
  }
  const bal = DB.getBalance(req.user.id)
  res.json(bal)
})

// deposit
app.post('/api/deposit', (req,res)=>{
  const amt = Number(req.body.amount)
  if(!req.user){
    const demo = DB.demoDeposit(amt)
    return res.json(demo)
  }
  if(!amt || amt<=0) return res.status(400).json({message:'Invalid'})
  const updated = DB.deposit(req.user.id, amt)
  res.json(updated)
})

// withdraw
app.post('/api/withdraw', (req,res)=>{
  const amt = Number(req.body.amount)
  if(!req.user){
    const demo = DB.demoWithdraw(amt)
    return res.json(demo)
  }
  if(!amt || amt<=0) return res.status(400).json({message:'Invalid'})
  const updated = DB.withdraw(req.user.id, amt)
  res.json(updated)
})

// accrue manual (accrues for all users on server)
app.post('/api/accrue', (req,res)=>{
  const result = DB.accrueAll()
  res.json(result)
})

const PORT = process.env.PORT || 4000
app.listen(PORT, ()=>console.log('Server listening on',PORT))
