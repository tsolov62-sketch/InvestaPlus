const fs = require('fs')
const path = require('path')
const Database = require('better-sqlite3')
const dbFile = path.join(__dirname,'../data/db.sqlite')
const DIR = path.dirname(dbFile)
if(!fs.existsSync(DIR)) fs.mkdirSync(DIR,{recursive:true})
const db = new Database(dbFile)

function init(){
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, password TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS balances (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, balance REAL DEFAULT 0, last_update DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, type TEXT, amount REAL, date TEXT);
  `)
}
init()

module.exports = {
  getUserByEmail(email){
    return db.prepare('SELECT * FROM users WHERE email = ?').get(email)
  },
  createUser(email,hash){
    const info = db.prepare('INSERT INTO users (email,password) VALUES (?,?)').run(email,hash)
    const id = info.lastInsertRowid
    db.prepare('INSERT INTO balances (user_id,balance,last_update) VALUES (?,?,?)').run(id,0,new Date().toISOString())
    return id
  },
  getBalance(userId){
    const b = db.prepare('SELECT * FROM balances WHERE user_id = ?').get(userId)
    const h = db.prepare('SELECT date,type,amount FROM history WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(userId)
    return {balance: b? b.balance : 0, history: h}
  },
  deposit(userId,amt){
    const b = db.prepare('SELECT * FROM balances WHERE user_id = ?').get(userId)
    if(!b) return null
    const newBal = Number((b.balance + amt).toFixed(8))
    db.prepare('UPDATE balances SET balance = ?, last_update = ? WHERE user_id = ?').run(newBal, new Date().toISOString(), userId)
    db.prepare('INSERT INTO history (user_id,type,amount,date) VALUES (?,?,?,?)').run(userId,'deposit',amt,new Date().toISOString().slice(0,10))
    return this.getBalance(userId)
  },
  withdraw(userId,amt){
    const b = db.prepare('SELECT * FROM balances WHERE user_id = ?').get(userId)
    if(!b) return null
    if(amt > b.balance) return {error:'Insufficient'}
    const newBal = Number((b.balance - amt).toFixed(8))
    db.prepare('UPDATE balances SET balance = ?, last_update = ? WHERE user_id = ?').run(newBal, new Date().toISOString(), userId)
    db.prepare('INSERT INTO history (user_id,type,amount,date) VALUES (?,?,?,?)').run(userId,'withdraw',amt,new Date().toISOString().slice(0,10))
    return this.getBalance(userId)
  },
  // demo local non-auth functions
  getDemo(){
    const p = path.join(__dirname,'../data/demo.json')
    if(!fs.existsSync(p)) return {balance:0,history:[]}
    return JSON.parse(fs.readFileSync(p,'utf8'))
  },
  demoDeposit(amt){
    const p = path.join(__dirname,'../data/demo.json')
    let obj = {balance:0,history:[]}
    if(fs.existsSync(p)) obj = JSON.parse(fs.readFileSync(p,'utf8'))
    obj.balance = Number((obj.balance + amt).toFixed(8))
    obj.history.push({date:new Date().toISOString().slice(0,10),type:'deposit',amount:amt})
    fs.writeFileSync(p,JSON.stringify(obj,null,2))
    return obj
  },
  demoWithdraw(amt){
    const p = path.join(__dirname,'../data/demo.json')
    let obj = {balance:0,history:[]}
    if(fs.existsSync(p)) obj = JSON.parse(fs.readFileSync(p,'utf8'))
    if(amt > obj.balance) return {error:'Insufficient'}
    obj.balance = Number((obj.balance - amt).toFixed(8))
    obj.history.push({date:new Date().toISOString().slice(0,10),type:'withdraw',amount:amt})
    fs.writeFileSync(p,JSON.stringify(obj,null,2))
    return obj
  },
  accrueAll(){
    // 1% per day compound for all user balances based on days since last_update
    const rows = db.prepare('SELECT * FROM balances').all()
    const DAY_MS = 86400000
    rows.forEach(r=>{
      const last = new Date(r.last_update)
      const now = new Date()
      const days = Math.floor((now.getTime() - last.getTime())/DAY_MS)
      if(days<=0) return
      let bal = r.balance
      for(let i=0;i<days;i++){
        const interest = bal * 0.01
        bal = Number((bal + interest).toFixed(8))
      }
      db.prepare('UPDATE balances SET balance = ?, last_update = ? WHERE id = ?').run(bal, new Date().toISOString(), r.id)
      db.prepare('INSERT INTO history (user_id,type,amount,date) VALUES (?,?,?,?)').run(r.user_id,'accrue',Number((bal - r.balance).toFixed(8)), new Date().toISOString().slice(0,10))
    })
    return {ok:true}
  }
}
