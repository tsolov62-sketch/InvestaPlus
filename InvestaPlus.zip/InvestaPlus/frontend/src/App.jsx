import React, {useState, useEffect} from 'react'
import { translations } from './translations'
import Header from './components/Header'
import Login from './components/Login'
import Register from './components/Register'
import Dashboard from './components/Dashboard'

const STORAGE_LANG = 'investa_lang'
const STORAGE_TOKEN = 'investa_token'

export default function App(){
  const [lang, setLang] = useState(localStorage.getItem(STORAGE_LANG) || 'bg')
  const [page, setPage] = useState('home') // home, login, register, dashboard
  const [token, setToken] = useState(localStorage.getItem(STORAGE_TOKEN) || null)

  useEffect(()=>{
    localStorage.setItem(STORAGE_LANG, lang)
  },[lang])

  function t(key){ return translations[lang][key] || key }

  function handleLoginDone(jwt){
    setToken(jwt)
    localStorage.setItem(STORAGE_TOKEN, jwt)
    setPage('dashboard')
  }
  function handleLogout(){
    setToken(null)
    localStorage.removeItem(STORAGE_TOKEN)
    setPage('home')
  }

  return (
    <div className="app">
      <div className="card">
        <Header t={(k)=>t(k)} lang={lang} setLang={setLang} onNavigate={(p)=>setPage(p)} isLoggedIn={!!token} onLogout={handleLogout} />
        <div style={{marginTop:12}}>
          <h2>{t('subtitle')}</h2>
          {page==='home' && (
            <div style={{marginTop:12}}>
              <p className="small">Demo platform — използвай тестова мрежа за реални транзакции.</p>
              <div style={{marginTop:12, display:'flex', gap:8}}>
                <button className="btn" onClick={()=>setPage('login')}>{t('login')} / {t('register')}</button>
                <button className="btn-ghost" onClick={()=>setPage('dashboard')}>Open demo (no auth)</button>
              </div>
            </div>
          )}
          {page==='login' && <Login t={(k)=>t(k)} onDone={handleLoginDone} onSwitch={()=>setPage('register')} />}
          {page==='register' && <Register t={(k)=>t(k)} onDone={handleLoginDone} onSwitch={()=>setPage('login')} />}
          {page==='dashboard' && <Dashboard t={(k)=>t(k)} token={token} />}
        </div>
      </div>
    </div>
  )
}
