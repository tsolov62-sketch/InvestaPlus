export const translations = {
  en: {
    title: "InvestaPlus",
    subtitle: "DeFi demo — 1% daily compound interest (TRX)",
    login: "Login",
    register: "Register",
    logout: "Logout",
    deposit: "Deposit",
    withdraw: "Withdraw",
    amount: "Amount",
    balance: "Balance",
    accrue: "Accrue Now",
    simulate: "Simulate",
    lang: "EN",
    email: "Email",
    password: "Password",
    submit: "Submit"
  },
  bg: {
    title: "InvestaPlus",
    subtitle: "DeFi демо — 1% дневна сложна лихва (TRX)",
    login: "Вход",
    register: "Регистрация",
    logout: "Изход",
    deposit: "Депозит",
    withdraw: "Теглене",
    amount: "Сума",
    balance: "Баланс",
    accrue: "Начисли сега",
    simulate: "Симулирай",
    lang: "BG",
    email: "Имейл",
    password: "Парола",
    submit: "Изпрати"
  }
}
