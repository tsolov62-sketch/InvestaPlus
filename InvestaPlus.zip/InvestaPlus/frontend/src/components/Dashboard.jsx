import React, {useState, useEffect} from 'react'

const DAILY_RATE = 0.01

function format(n){ return Number(n).toFixed(6) }

export default function Dashboard({t,token}){
  const [balance,setBalance] = useState(0)
  const [deposit,setDeposit] = useState('')
  const [withdraw,setWithdraw] = useState('')
  const [history,setHistory] = useState([])

  useEffect(()=>{
    // load from /api or local demo
    async function load(){
      try{
        const res = await fetch('/api/balance', {headers:{'Authorization': token? 'Bearer '+token : ''}})
        if(res.ok){
          const j = await res.json()
          setBalance(j.balance||0)
          setHistory(j.history||[])
        } else {
          // fallback demo from localStorage
          const raw = localStorage.getItem('investa_demo')
          if(raw){
            const parsed = JSON.parse(raw)
            setBalance(parsed.balance||0)
            setHistory(parsed.history||[])
          }
        }
      }catch(err){}
    }
    load()
  },[token])

  async function doDeposit(){
    const amt = Number(deposit)
    if(!amt) return alert('Invalid')
    try{
      const res = await fetch('/api/deposit',{method:'POST',headers:{'Content-Type':'application/json','Authorization': token? 'Bearer '+token : ''},body:JSON.stringify({amount:amt})})
      const j = await res.json()
      if(res.ok){ setBalance(j.balance); setHistory(j.history) } else alert(j.message)
    }catch(err){ alert('Server error') }
    setDeposit('')
  }

  async function doWithdraw(){
    const amt = Number(withdraw)
    if(!amt) return alert('Invalid')
    try{
      const res = await fetch('/api/withdraw',{method:'POST',headers:{'Content-Type':'application/json','Authorization': token? 'Bearer '+token : ''},body:JSON.stringify({amount:amt})})
      const j = await res.json()
      if(res.ok){ setBalance(j.balance); setHistory(j.history) } else alert(j.message)
    }catch(err){ alert('Server error') }
    setWithdraw('')
  }

  async function accrueNow(){
    try{
      const res = await fetch('/api/accrue',{method:'POST',headers:{'Authorization': token? 'Bearer '+token : ''}})
      const j = await res.json()
      if(res.ok){ setBalance(j.balance); setHistory(j.history) } else alert(j.message)
    }catch(err){ alert('Server error') }
  }

  function simulate(days){
    let arr=[]
    let bal=balance
    for(let i=1;i<=days;i++){
      const interest = bal*DAILY_RATE
      bal = bal + interest
      arr.push({day:i,balance:bal,interest})
    }
    return arr
  }

  const sim = simulate(30)

  return (
    <div style={{marginTop:12}}>
      <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
        <div className="card" style={{minWidth:220}}>
          <div className="small">{t('balance')}</div>
          <div style={{fontFamily:'monospace',fontSize:20,marginTop:8}}>{format(balance)} TRX</div>
          <div className="small" style={{marginTop:8}}>Daily: 1%</div>
          <div style={{marginTop:12,display:'flex',gap:8}}>
            <button className="btn" onClick={accrueNow}>{t('accrue')}</button>
          </div>
        </div>

        <div className="card" style={{minWidth:320}}>
          <div className="small">Action</div>
          <div style={{marginTop:8,display:'flex',gap:8}}>
            <input className="input" placeholder={t('amount')} value={deposit} onChange={e=>setDeposit(e.target.value)} />
            <button className="btn" onClick={doDeposit}>{t('deposit')}</button>
          </div>
          <div style={{marginTop:8,display:'flex',gap:8}}>
            <input className="input" placeholder={t('amount')} value={withdraw} onChange={e=>setWithdraw(e.target.value)} />
            <button className="btn" onClick={doWithdraw}>{t('withdraw')}</button>
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:12}}>
        <div className="small">Simulation (30 days)</div>
        <table className="table">
          <thead><tr><th>Day</th><th>Interest</th><th>Balance</th></tr></thead>
          <tbody>
            {sim.map(s=>(
              <tr key={s.day}><td>{s.day}</td><td>{s.interest.toFixed(6)}</td><td>{s.balance.toFixed(6)} TRX</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{marginTop:12}}>
        <div className="small">History (recent)</div>
        <table className="table">
          <thead><tr><th>Date</th><th>Type</th><th>Amount</th></tr></thead>
          <tbody>
            {history.slice(-10).reverse().map((h,idx)=>(
              <tr key={idx}><td>{h.date}</td><td>{h.type}</td><td>{h.amount?.toFixed? h.amount.toFixed(6) : ''}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
