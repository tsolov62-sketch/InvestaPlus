import React from 'react'

export default function Header({t, lang, setLang, onNavigate, isLoggedIn, onLogout}){
  return (
    <div className="header">
      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <div style={{fontWeight:700}}>{t('title')}</div>
        <div className="small">{t('subtitle')}</div>
      </div>
      <div style={{display:'flex',gap:8,alignItems:'center'}}>
        <button className="language-btn" onClick={()=>setLang(lang==='bg'?'en':'bg')}>{lang==='bg'?'EN':'BG'}</button>
        {isLoggedIn ? (
          <button className="btn-ghost" onClick={onLogout}>{t('logout')}</button>
        ) : (
          <button className="btn" onClick={()=>onNavigate('login')}>{t('login')}</button>
        )}
      </div>
    </div>
  )
}
