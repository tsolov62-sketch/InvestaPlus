import React, {useState} from 'react'

export default function Register({t,onDone,onSwitch}){
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')

  async function submit(e){
    e.preventDefault()
    try{
      const res = await fetch('/api/auth/register', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({email,password})
      })
      const j = await res.json()
      if(res.ok && j.token){
        onDone(j.token)
      } else {
        alert(j.message || 'Register failed')
      }
    }catch(err){
      alert('Server error')
    }
  }

  return (
    <form onSubmit={submit} style={{marginTop:12}}>
      <div className="field"><input className="input" placeholder={t('email')} value={email} onChange={e=>setEmail(e.target.value)} /></div>
      <div className="field" style={{marginTop:8}}><input className="input" type="password" placeholder={t('password')} value={password} onChange={e=>setPassword(e.target.value)} /></div>
      <div style={{marginTop:12, display:'flex', gap:8}}>
        <button className="btn" type="submit">{t('register')}</button>
        <button type="button" className="btn-ghost" onClick={onSwitch}>{t('login')}</button>
      </div>
    </form>
  )
}
